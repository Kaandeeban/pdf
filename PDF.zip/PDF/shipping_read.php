<?php 

require 'vendor/autoload.php';
include 'send_emails.php'; 
require 'dbconnection.php';   

require_once 'Log4php/Logger.php';
Logger::configure(__DIR__.'/Logs.xml');
$logger = Logger::getLogger('shipping_read.php');
date_default_timezone_set("Asia/Singapore");
error_reporting(1);

$curr_dt = date('Y-m-d H:i:s');

/**  Define a Read Filter class implementing \PhpOffice\PhpSpreadsheet\Reader\IReadFilter  */
class MyReadFilter implements \PhpOffice\PhpSpreadsheet\Reader\IReadFilter
{
    private $startRow = 0;
    private $endRow   = 0;
    private $columns  = [];

    /**  Get the list of rows and columns to read  */
    public function __construct($startRow, $endRow, $columns) {
        $this->startRow = $startRow;
        $this->endRow   = $endRow;
        $this->columns  = $columns;
    }

    public function readCell($column, $row, $worksheetName = '') {
        //  Only read the rows and columns that were configured
        if ($row >= $this->startRow && $row <= $this->endRow) {
            if (in_array($column,$this->columns)) {
                return true;
            }
        }
        return false;
    }
}

$date_excelread = date('Y-m-d H:i:s');

// Windows 
$path = glob(__DIR__.'/files/ShippingAdvice*.{xlsx}', GLOB_BRACE);

if (count($path) > 0) {

    $start="Shipping Advise Read Start";
    $logger->info("**********************$start**********************\n");

    // Start looping the excel files
    foreach ($path as $key => $filename) {
 
        $path_parts       = pathinfo($filename);
        $actual_file_name = trim($path_parts['filename']);

        $logger->info("Following files is parsed: $filename \n");

        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader('Xlsx');
        $reader->setReadDataOnly(TRUE);
        $spreadsheet = $reader->load($filename);

        $worksheet = $spreadsheet->getActiveSheet();
        // Get the highest row and column numbers referenced in the worksheet
        $highestRow         = $worksheet->getHighestRow();
        $highestColumn      = $worksheet->getHighestColumn();
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

        $cordinate_array        = array();
        //echo '<table style="border: 1px solid #000;">' . "\n";
        for ($row = 1; $row <= $highestRow; ++$row) {
            // echo '<tr style="border: 1px solid #000;">' . PHP_EOL;
            for ($col = 1; $col <= $highestColumnIndex; ++$col) {
                $value = $worksheet->getCellByColumnAndRow($col, $row)->getValue();
                if ($value !== null) {
                    // if (stripos($value, 'Date/Time') !== false) {
                    //     $cordinate_array['date-time']['start'] = ($row)."_".ColNoToLetter($col+2);
                    //     $cordinate_array['date-time']['end'] = ($row)."_".ColNoToLetter($col+3);
                    // } 

                    if (stripos($value, 'File Ref. Nr:') !== false) {
                       $cordinate_array['file-ref']['start']  = ($row)."_".ColNoToLetter($col);
                       $cordinate_array['file-ref']['end']    = ($row)."_".ColNoToLetter($col);
                    } 

                    if (stripos($value, 'Product:') !== false) {
                        $cordinate_array['product']['start'] = ($row)."_".ColNoToLetter($col+4);
                        $cordinate_array['product']['end']  = ($row)."_".ColNoToLetter($col+5);

                        $cordinate_array['product1']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['product1']['end']   = ($row)."_".ColNoToLetter($col+3);

                        $cordinate_array['product2']['start'] = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['product2']['end']   = ($row)."_".ColNoToLetter($col+2);
                    } 

                    if (stripos($value, 'Loading Place:') !== false) {
                        $cordinate_array['loading-place']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['loading-place']['end']   = ($row)."_".ColNoToLetter($col+3);
                    }

                    if (stripos($value, 'Vessel:') !== false) {
                        $cordinate_array['vessel']['start'] = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['vessel']['end']  = ($row)."_".ColNoToLetter($col+2);
                    }

                    if (stripos($value, 'ATD:') !== false) {
                        $cordinate_array['atd']['start'] = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['atd']['end']  = ($row)."_".ColNoToLetter($col+2);
                    }

                    if (stripos($value, 'ETA:') !== false) {
                        $cordinate_array['eta']['start'] = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['eta']['end']  = ($row)."_".ColNoToLetter($col+2);
                    }

                    if (stripos($value, 'Place of Delivery:') !== false) {
                        $cordinate_array['delivery-place']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['delivery-place']['end']   = ($row)."_".ColNoToLetter($col+3);
                    }

                    // if (stripos($value, 'Free Days:') !== false) {
                    //     $cordinate_array['free-days']['start'] = ($row)."_".ColNoToLetter($col+3);
                    // }

                    // if (stripos($value, 'Rate per Day:') !== false) {
                    //     $cordinate_array['free-days']['end'] = ($row-1)."_".ColNoToLetter($col+4);
                    //     $cordinate_array['rate']['start'] = ($row)."_".ColNoToLetter($col+3);
                    //     $cordinate_array['rate']['end']   = ($row)."_".ColNoToLetter($col+4);
                    // }
                    if (stripos($value, 'Terms:') !== false && !isset($cordinate_array['terms']['end'])) {
                        $cordinate_array['terms']['start'] = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['terms']['end']   = ($row)."_".ColNoToLetter($col+2);
                       
                        $cordinate_array['terms1']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['terms1']['end']   = ($row)."_".ColNoToLetter($col+3);
                    }

                    if (stripos($value, 'Tank Number') !== false) {
                        $cordinate_array['tank-details']['start'] = ($row+1);
                    } 

                    if (stripos($value, 'Total Weight/Volume:') !== false) {
                        $cordinate_array['tank-details']['end']   = ($row-1);
                        $cordinate_array['uom']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['uom']['end']   = ($row)."_".ColNoToLetter($col+3);
                    }

                    if (stripos($value, 'Number of units:') !== false) {
                        $cordinate_array['no-units']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['no-units']['end']   = ($row)."_".ColNoToLetter($col+3);
                    }
                    
                    if (stripos($value, 'Product Instructions:') !== false) {
                        $cordinate_array['product-inst']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['product-inst']['end']   = ($row)."_".ColNoToLetter($col+3);
                    }

                    if (stripos($value, 'Master B/L:') !== false) {
                        $cordinate_array['master-bl']['start'] = ($row);
                        $cordinate_array['master-bl']['end']   = ($row);
                    }

                    if (stripos($value, 'House B/L:') !== false) {
                        $cordinate_array['house-bl']['start'] = ($row);
                        $cordinate_array['house-bl']['end']   = ($row);
                    }

                    if (stripos($value, 'Kind regards') !== false) {
                        $cordinate_array['signature']['start'] = ($row+1)."_".ColNoToLetter($col);
                        $cordinate_array['signature']['end']   = ($row+1)."_".ColNoToLetter($col);
                    }

                    if (stripos($value, 'Special Instructions') !== false) {
                        $cordinate_array['spl-inst']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['spl-inst']['end']   = ($row+5)."_".ColNoToLetter($col+3);
                    }
                    
                    // echo '<td style="border: 1px solid #000;">' . $value . '</td>' . PHP_EOL;                 
                }
            }
           //  echo '</tr>' . PHP_EOL;
        }
        // echo '</table>' . PHP_EOL;

        $final_sheetData    = array();
        $sheetData          = array();
        $insert_array       = array();

        foreach ($cordinate_array as $cordinate_key => $cordinate_value) {
            list($row, $col) = explode('_', $cordinate_value['start']);
            /**  Create an Instance of our Read Filter, passing in the cell range  **/
            $filterSubset = new MyReadFilter($row,$cordinate_value['end'],range($col,$col));
            $reader->setReadFilter($filterSubset);

            $spreadsheet = $reader->load($filename);
            $sheetData   = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
            // remove empty elements from array
            $sheetData = array_map('array_filter', $sheetData);
            $final_sheetData[$cordinate_key] = array_filter($sheetData);
            
        }

        // echo "<pre>";
        // print_r($final_sheetData);
        // echo "</pre>";
        // exit;

        foreach ($final_sheetData as $key => $value) {
            $final_string = "";
            foreach ($value as $key1 => $value1) {
                foreach ($value1 as $key2 => $value2) {
                    $final_string .= $value2.PHP_EOL;
                }
                $insert_array[$key] = $final_string;
            }
        }

        $i=0;
        foreach ($final_sheetData['tank-details'] as $key => $value) {
            $data[$i]['tank-no'] = $value['D'];
            $data[$i]['ins-dt'] = $value['L'];
            $i++;
        }

        // echo "<pre>";
        // print_r($insert_array);
        // echo "</pre>";
        // exit;

        $logger->info("Final Array:  $insert_array \n");

        $sql     = "SELECT TOP 1 id,bertschi_ref FROM Bertschi_Imports_Data_Log ORDER BY id DESC";
        $res     = sqlsrv_query($conn, $sql);
        $row     = sqlsrv_fetch_array($res, SQLSRV_FETCH_NUMERIC);
        $rowid   = $row[0];
        $ber_ref = $row[1];

        $ber_ref_no = end(explode('Nr:',$insert_array['file-ref']));
        
        if($ber_ref == trim($ber_ref_no)) {
           $product    = trim($insert_array['product']).trim($insert_array['product1']).trim($insert_array['product2']);
           $load_place = trim($insert_array['loading-place']);
           $vessel     = explode(';', $insert_array['vessel']);
           $atd        = date("Y-m-d", strtotime($insert_array['atd']));
           $eta        = date("Y-m-d", strtotime($insert_array['eta']));
           $pl_del     = (trim($insert_array['delivery-place']) == 'Ad Dammam') ? 'Dammam' : trim($insert_array['delivery-place']);
        
           $terms = ($insert_array['terms'] == '') ? trim($insert_array['terms1']): trim($insert_array['terms']);
           $no_units  = explode('X',$insert_array['no-units']);
           $cont_size = explode('SO',$no_units[1]);
           $cont_size = str_replace("'", " ", $cont_size);

           $master_bl   = explode('Master B/L:',$insert_array['master-bl']);
           $mast_bl_no  = explode('Originals:',$master_bl[1]);
           $master_org  = explode('Copies:',$mast_bl_no[1]);

           $house_org   = explode('Originals:',$insert_array['house-bl']);
           $house_cpy   = explode('Copies:', $house_org[1]);

           $prod_inst   = trim($insert_array['product-inst']);
           $spl_inst    = explode('<br>', wordwrap(str_replace("'", "''",$insert_array['spl-inst']),70, '<br>'));
           $username    = trim($insert_array['signature']);

           $uom = preg_replace('/[0-9]+/', '', $insert_array['uom']);

           $update = "UPDATE Bertschi_Imports_Data_Log SET prod_id = '$product',load_place='$load_place',
                    vessel='".trim($vessel[0])."',voyage='".trim($vessel[1])."',atd='$atd',eta='$eta',
                    place_delivery='$pl_del',currency='USD',
                    move_type='$terms',no_of_units='".trim($no_units[0])."',cont_size='".trim($cont_size[0])."',
                    master_bl='".$mast_bl_no[0]."',master_bl_org='".trim($master_org[0])."',
                    master_bl_cpy='".trim($master_org[1])."',
                    house_bl_org='".trim($house_cpy[0])."',house_bl_cpy='".trim($house_cpy[1])."',prod_inst='$prod_inst',
                    spl_inst1='".$spl_inst[0]."',spl_inst2='".$spl_inst[1]."',spl_inst3='".$spl_inst[2]."',
                    spl_inst4='".$spl_inst[3]."',spl_inst5='".$spl_inst[4]."',spl_inst6='".$spl_inst[5]."',
                    username='$username',isshipadvice='Y'
                    WHERE id = '$rowid' and bertschi_ref = '$ber_ref'";
            $result = sqlsrv_query($conn,$update);
            if ($result) {
                if (copy ($filename, __DIR__.'/files/processed/'.basename($filename))) {
                    unlink($filename);
                }
                foreach ($data as $key => $value) {
                    $stmt = "UPDATE Bertschi_Imports_Tank_Details SET uom = '".trim($uom)."',
                            next_insp_dt = '".$value['ins-dt']."' WHERE bertschi_ref = '$ber_ref'
                            and tank_no = '".$value['tank-no']."'";
                    sqlsrv_query($conn,$stmt);
                }
            }else {
                if (copy ($filename, __DIR__.'/files/error/'.basename($filename))) {
                    unlink($filename);
                }
                $path = glob(__DIR__.'/files/*.{pdf}', GLOB_BRACE);
                foreach ($path as $key => $value) {
                    if (copy ($value, __DIR__.'/files/pdf_error/'.basename($value))) {
                        unlink($value);
                    }
                }
                SentEmailInsertError($update);
            }
        }
        else {
            if (copy ($filename, __DIR__.'/files/error/'.basename($filename))) {
                unlink($filename);
            }
            $path = glob(__DIR__.'/files/*.{pdf}', GLOB_BRACE);
            foreach ($path as $key => $value) {
                if (copy ($value, __DIR__.'/files/pdf_error/'.basename($value))) {
                    unlink($value);
                }
            }
            $sql  = "DELETE FROM Bertschi_Imports_Data_Log WHERE id = '$rowid'";
            $res  = sqlsrv_query($conn, $sql);
            SentEmailInsertError('Shipping Read Failed');
        }
    }
    $end="Shipping Advise Read End";
    $logger->info("**********************$end**********************\n");
}



function ColNoToLetter($col)
{
    $numeric = ($col - 1) % 26;
    $letter  = chr(65 + $numeric);
    $num2    = intval(($col - 1) / 26);
    if ($num2 > 0) {
        return ColNoToLetter($num2) . $letter;
    } else {
        return $letter;
    }
}

 