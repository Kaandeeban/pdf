<?php 
$db_host = 'DB11N-KAANDEEBA\SQLEXPRESS';
$db_port = 1433;
$db_name = 'bertPDF';
$db_user = 'sa';
$db_pass = 'sa';



$connectionInfo = array( "UID"=>$db_user,
                         "PWD"=>$db_pass,
                         "Database"=>$db_name);



// Connect using SQL Server Authentication.
$conn= sqlsrv_connect($db_host,$connectionInfo);


