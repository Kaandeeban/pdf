<?php
require 'vendor/autoload.php';
require_once 'Log4php/Logger.php';

//Logger::configure(__DIR__.'/315LogConfig.xml');
$logger = Logger::getLogger('convert_files.php');
date_default_timezone_set("Asia/Singapore");

// $start = "Bertschi Import Convert Files";
// $logger->info("**********************$start**********************\n");

$paths = glob(__DIR__.'/files/*.{xlsx}', GLOB_BRACE);
foreach ($paths as $key => $values) {
    if (copy ($values, __DIR__.'/files/error/'.basename($values))) {
        unlink($values);
    }
}

// windows
$dest    = __DIR__.'/files/';
$paths[]    = glob(__DIR__.'/files/*.[pP][dD][fF]', GLOB_BRACE);
//$paths[]    = glob(__DIR__.'/files/HouseBL*.[pP][dD][fF]', GLOB_BRACE);
if (count($paths) > 0) {  
    foreach ($paths as $key => $path) {
       
    foreach ($path as $key => $value) {
        
        $logger->info("Following files is converted: $value \n");

        $pdffilename = $value;
		$name = str_replace('.pdf', '', $pdffilename);
        if (file_exists($name.'xlsx')) unlink($name.'xlsx');
        $c = new COM("PDFConverter.PDFConverterX");
        $c->convert($value,$name, "-c XLS");
        if (file_exists($dest)) echo ""; else echo "fail:".$c->ErrorMessage;
    }

}
    $logger->info("Successfully converted \n");
    echo "Successfully converted";
} else {
    $logger->info("No files to convert \n");
    echo "No files to convert";
}
