<?php 
require 'dbconnection.php'; 


require 'vendor/autoload.php';
require_once 'Log4php/Logger.php';
Logger::configure(__DIR__.'/Logs.xml');
$logger = Logger::getLogger('housebl_read.php');
date_default_timezone_set("Asia/Singapore");
error_reporting(1);

$curr_dt = date('Y-m-d H:i:s');

/**  Define a Read Filter class implementing \PhpOffice\PhpSpreadsheet\Reader\IReadFilter  */
class MyReadFilter implements \PhpOffice\PhpSpreadsheet\Reader\IReadFilter
{
    private $startRow = 0;
    private $endRow   = 0;
    private $columns  = [];

    /**  Get the list of rows and columns to read  */
    public function __construct($startRow, $endRow, $columns) {
        $this->startRow = $startRow;
        $this->endRow   = $endRow;
        $this->columns  = $columns;
    }

    public function readCell($column, $row, $worksheetName = '') {
        //  Only read the rows and columns that were configured
        if ($row >= $this->startRow && $row <= $this->endRow) {
            if (in_array($column,$this->columns)) {
                return true;
            }
        }
        return false;
    }
}

$date_excelread = date('Y-m-d H:i:s');

// Windows 
$path = glob(__DIR__.'/files/Invoice*.{xlsx}', GLOB_BRACE);

if (count($path) > 0) {

    $start="House BL Read Start";
    $logger->info("**********************$start**********************\n");

    // Start looping the excel files
    foreach ($path as $key => $filename) {
 
        $path_parts       = pathinfo($filename);
        $actual_file_name = trim($path_parts['filename']);

        $logger->info("Following files is parsed: $filename \n");

        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader('Xlsx');
        $reader->setReadDataOnly(TRUE);
        $spreadsheet = $reader->load($filename);

        $worksheet = $spreadsheet->getActiveSheet();
        // Get the highest row and column numbers referenced in the worksheet
        $highestRow         = $worksheet->getHighestRow();
        $highestColumn      = $worksheet->getHighestColumn();
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

        $cordinate_array        = array();
        $cont_num = 0;
      //  echo '<table style="border: 1px solid #000;">' . "\n";
        for ($row = 1; $row <= $highestRow; ++$row) {
           // echo '<tr style="border: 1px solid #000;">' . PHP_EOL;
            for ($col = 1; $col <= $highestColumnIndex; ++$col) {
                $value = $worksheet->getCellByColumnAndRow($col, $row)->getValue();
                if ($value !== null) {
                    if (stripos($value, 'Bertschi North America Inc.')!== false && !isset($cordinate_array['bertschi-add']['start'])) {
                        $cordinate_array['bertschi-add']['start'] = ($row)."_".ColNoToLetter($col);
                        $cordinate_array['bertschi-add']['end']   = ($row+4)."_".ColNoToLetter($col);
                    } 
                    if (stripos($value, 'Invoice Number:') !== false) {
                        $cordinate_array['invoice-no']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['invoice-no']['end']   = ($row)."_".ColNoToLetter($col+2);
                    } 
                    if (stripos($value, 'Invoice Date:') !== false) {
                        $cordinate_array['invoice-date']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['invoice-date']['end']   = ($row)."_".ColNoToLetter($col+2);
                    }
                    if (stripos($value, 'The Lubrizol Corporation') !== false && !isset($cordinate_array['lubrizol-add']['start'])) {
                        $cordinate_array['lubrizol-add']['start'] = ($row)."_".ColNoToLetter($col);
                        $cordinate_array['lubrizol-add']['end'] = ($row+4)."_".ColNoToLetter($col);
                    }
                    if (stripos($value, 'Debtor Nr:') !== false && !isset($cordinate_array['debtor']['start'])) {
                        $cordinate_array['debtor']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['debtor']['end'] = ($row)."_".ColNoToLetter($col+5);
                    }
                    if (stripos($value, 'Your Reference:') !== false && !isset($cordinate_array['your-ref']['start'])) {
                        $cordinate_array['your-ref']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['your-ref']['end'] = ($row)."_".ColNoToLetter($col+5);
                    }
                    if (stripos($value, 'Your VAT Number:') !== false && !isset($cordinate_array['your-vat']['start'])) {
                        $cordinate_array['your-vat']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['your-vat']['end'] = ($row)."_".ColNoToLetter($col+5);
                    }
                    if (stripos($value, 'ATD:') !== false && !isset($cordinate_array['ATD']['start'])) {
                        $cordinate_array['ATD']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['ATD']['end'] = ($row)."_".ColNoToLetter($col+3);
                    }
                    if (stripos($value, 'Product:') !== false && !isset($cordinate_array['prod']['start'])) {
                        $cordinate_array['prod']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['prod']['end'] = ($row)."_".ColNoToLetter($col+3);
                    }
                    if (stripos($value, 'Offernumber(s):') !== false && !isset($cordinate_array['off-num']['start'])) {
                        $cordinate_array['off-num']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['off-num']['end'] = ($row)."_".ColNoToLetter($col+5);
                    }
                    if (stripos($value, 'Destination:') !== false && !isset($cordinate_array['dest']['start'])) {
                        $cordinate_array['dest']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['dest']['end'] = ($row)."_".ColNoToLetter($col+5);
                    }
                    
                    if (stripos($value, 'HBL Nr:') !== false && !isset($cordinate_array['hbl']['start'])) {
                        $cordinate_array['hbl']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['hbl']['end'] = ($row)."_".ColNoToLetter($col+5);
                    }
                    if (stripos($value, 'Our Reference:') !== false && !isset($cordinate_array['our-ref']['start'])) {
                        $cordinate_array['our-ref']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['our-ref']['end'] = ($row)."_".ColNoToLetter($col+3);
                    }
                    if (stripos($value, 'Our VAT Number:') !== false && !isset($cordinate_array['our-vat']['start'])) {
                        $cordinate_array['our-vat']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['our-vat']['end'] = ($row)."_".ColNoToLetter($col+3);
                    }
                    if (stripos($value, 'Origin:') !== false && !isset($cordinate_array['Origin']['start'])) {
                        $cordinate_array['Origin']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['Origin']['end'] = ($row)."_".ColNoToLetter($col+3);
                    }
                    if (stripos($value, 'Vessel:') !== false && !isset($cordinate_array['vessel']['start'])) {
                        $cordinate_array['vessel']['start'] = ($row)."_".ColNoToLetter($col+2);
                        $cordinate_array['vessel']['end'] = ($row)."_".ColNoToLetter($col+3);
                    }
             
                        
                    if (stripos($value, 'Account No.:') !== false&& !isset( $cordinate_array['acc-num']['start'])) {
                        $cordinate_array['acc-num']['start'] = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['acc-num']['end']   = ($row)."_".ColNoToLetter($col+5);
                    }
                    if (stripos($value, 'Swift Code:') !== false && !isset( $cordinate_array['swift-code']['start'])) {
                        $cordinate_array['swift-code']['start']  = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['swift-code']['end'] = ($row)."_".ColNoToLetter($col+2);
                        
                    }
                    if (stripos($value, 'Routing Number:') !== false && !isset( $cordinate_array['route-num']['start'])) {
                        $cordinate_array['route-num']['start']  = ($row)."_".ColNoToLetter($col+3);
                        $cordinate_array['route-num']['end'] = ($row)."_".ColNoToLetter($col+5);
                        
                    }
                    if (stripos($value, 'Bank:') !== false && !isset( $cordinate_array['bank']['start'])) {
                        $cordinate_array['bank']['start']  = ($row)."_".ColNoToLetter($col+1);
                        $cordinate_array['bank']['end'] = ($row)."_".ColNoToLetter($col+2);
                        
                    }


                    if (stripos($value, 'Container Number') !== false ) {
                        $cordinate_array['cont-num']['start'] = ($row+1);
                       
                    }
                    if (stripos($value, 'Charge Description') !== false ) {
                        $cordinate_array['cont-num']['end'] = ($row-1); 
                        $cordinate_array['charge']['start'] = ($row+1); 
                    }
                    if (stripos($value, 'Ex VAT Subtotal:') !== false ) {
                        $cordinate_array['charge']['end'] = ($row-1);
                        $cordinate_array['ex-vat']['start'] = ($row);
                        $cordinate_array['ex-vat']['end'] = ($row+5);
                    }
                 //  echo '<td style="border: 1px solid #000;">' . $value . '</td>' . PHP_EOL;                 
                }
             }
           // echo '</tr>' . PHP_EOL;
        } 
    //   echo "<pre>";
    //     print_r($cordinate_array);
    //      die;

        $spreadsheet        = \PhpOffice\PhpSpreadsheet\IOFactory::load($filename);

        $sheetCount         = $spreadsheet->getSheetCount();  

        $sheet              = $spreadsheet->getSheet(0);

        $sheetDatas         = $sheet->toArray(null, true, true, true);  

        $container_details  = [];
        $charge_details     = [];
        $vat_details        = [];

        foreach ($sheetDatas as $key => $sheetData) {
                
            
            if($key >= $cordinate_array['cont-num']['start'] && $key <= $cordinate_array['cont-num']['end'] ){
                $container_details[] = $sheetData;
            }
            
            if($key >= $cordinate_array['charge']['start'] && $key <= $cordinate_array['charge']['end']     ){
                $charge_details [] = $sheetData;
            }
            if($key >= $cordinate_array['ex-vat']['start'] && $key <= $cordinate_array['ex-vat']['end']     ){
                $vat_details[] = $sheetData;
            }
             
        }


        // echo "<pre>";
        // print_r($vat_details);
        //  die;
    
        $final_sheetData    = array();
        $sheetData          = array();
        $insert_array       = array();

        foreach ($cordinate_array as $cordinate_key => $cordinate_value) {
            list($row, $col) = explode('_', $cordinate_value['start']);
            /**  Create an Instance of our Read Filter, passing in the cell range  **/
            $filterSubset = new MyReadFilter($row,$cordinate_value['end'],range($col,$col));
            $reader->setReadFilter($filterSubset);

            $spreadsheet = $reader->load($filename);
            $sheetData   = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
            // remove empty elements from array
            $sheetData = array_map('array_filter', $sheetData);
            $final_sheetData[$cordinate_key] = array_filter($sheetData);
            
        }

        // echo "<pre>";
        // print_r( $final_sheetData);
        // echo "</pre>";
        //  exit;

        foreach ($final_sheetData as $key => $value) {
            $final_string = "";
            foreach ($value as $key1 => $value1) {
                foreach ($value1 as $key2 => $value2) {
                    $final_string .= $value2.PHP_EOL;
                }
                $insert_array[$key] = $final_string;
            }
        }
        // $i=0;
        // foreach ($container_details['cont-num'] as $key => $value) {
        //      if(count($value) != 1) {
        //             $data[$i]['cont-no'] = $value['C'];
        //             $data[$i]['ur-ref'] = $value['F'];
              
        //             $i++;
        //     }
        // }
        //  echo "<pre>";
        //  print_r($insert_array['bertschi-add']);

        //  echo "</pre>";
        //  exit;

        $logger->info("Final Array:  $insert_array \n");

        $invoice_no   = trim($insert_array['invoice-no']);
        $invoice_date = trim($insert_array['invoice-date']);
        $debtor       = trim($insert_array['debtor']);
        $bertschi_add = explode('<br>', wordwrap(str_replace("'", "''",$insert_array['bertschi-add']),70, '<br>'));
        $lubrizol_add = explode('<br>', wordwrap(str_replace("'", "''",$insert_array['lubrizol-add']),70, '<br>'));
        $your_ref     = trim($insert_array['your-ref']);
        $your_vat     = trim($insert_array['your-vat']);
        $atd          = trim($insert_array['ATD']);
        $Product      = trim($insert_array['prod']);
        $off_num      = trim($insert_array['off-num']);
        $dest         = trim($insert_array['dest']);
        $hbl          = trim($insert_array['hbl']);
        $our_ref      = trim($insert_array['our-ref']);
        $our_vat      = trim($insert_array['our-vat']);
        $Origin       = trim($insert_array['Origin']);
        $vessel       = trim($insert_array['vessel']);
        $acc_num      = trim($insert_array['acc-num']);
        $swift_code   = trim($insert_array['swift-code']);
        $route_num    = trim($insert_array['route-num']);
        $bank         = trim($insert_array['bank']);
        //$cont_num   = trim($insert_array['cont-num']);
        $charge       = trim($insert_array['charge']);
        $ex_vat       = trim($insert_array['ex-vat']);
                        // $ord_sql = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT tricon_ref FROM php WHERE tricon_ref = '$tricon_ref'" ));
                    // $ord_no  =  $ord_sql['tricon_ref'];

                    // if($ord_no == $tricon_ref) {
                    //     SendEmailDuplicate($get_email,$subject);
                    //     $path = glob(__DIR__.'/files/*.{pdf}', GLOB_BRACE);
                    //     foreach ($path as $key => $value) {
                    //         if (copy ($value, __DIR__.'/files/pdf_error/'.basename($value))) {
                    //             unlink($value);
                    //         }
                    //     }
                    //     $paths = glob(__DIR__.'/files/*.{xlsx}', GLOB_BRACE);
                    //     foreach ($paths as $key => $values) {
                    //         if (copy ($values, __DIR__.'/files/error/'.basename($values))) {
                    //             unlink($values);
                    //         }
                    //     }
                    //     exit;
                    // }else 

        $sql = "INSERT INTO bert(invoice_num,invoice_date,bert_add1,bert_add2,bert_add3,bert_add4,bert_add5,lubrizol_add1,lubrizol_add2,lubrizol_add3,lubrizol_add4,your_ref,your_vat,our_ref,our_vat,atd,Product,off_num,dest,hbl,origin,vessel,acc_num,swift_code,route_num,bank,debator)
        values('$invoice_no', '$invoice_date','".$bertschi_add[0]."','".$bertschi_add[1]."', '".$bertschi_add[2]."',
        '".$bertschi_add[3]."', '".$bertschi_add[4]."','".$lubrizol_add[0]."','".$lubrizol_add[1]."','".$lubrizol_add[2]."',
        '".$lubrizol_add[3]."', '$your_ref', '$your_vat', '$our_ref', '$our_vat', '$atd','$Product','$off_num',
        '$dest',  '$hbl', '$Origin','$vessel','$acc_num','$swift_code', '$route_num','$bank',' $debtor')";                    //'".$value['cont-no']."','".$value['ur-ref']."')";
         $res= sqlsrv_query($conn,$sql);
               // echo $sql;
                        
         if($res) {
            foreach ($container_details  as $key => $value) {

                if($value['C'] != ''){
                
                    $stmt = "INSERT INTO bert_cont_details(container_num,your_ref)VALUES('".$value['C']."','".$value['F']."')";

                    sqlsrv_query($conn,$stmt);
                    echo $stmt;
                    echo "<pre>";
                    //print_r($value);

                }
               




                
            }
             die;
            if (copy ($filename, __DIR__.'/files/processed/'.basename($filename))) {
                unlink($filename);
            }
        }
        else {
            if (copy ($filename, __DIR__.'/files/error/'.basename($filename))) {
                unlink($filename);
            }
            //SentEmailInsertError($sql);
        }
        // echo "<pre>";
        //  print_r($sql);
        //  echo "</pre>";
        //  exit;
   
    }
    $end="House BL Read End";
    $logger->info("**********************$end**********************\n");
} 
function ColNoToLetter($col)
{
    $numeric = ($col - 1) % 26;
    $letter  = chr(65 + $numeric);
    $num2    = intval(($col - 1) / 26);
    if ($num2 > 0) {
        return ColNoToLetter($num2) . $letter;
    } else {
        return $letter;
    }
}
